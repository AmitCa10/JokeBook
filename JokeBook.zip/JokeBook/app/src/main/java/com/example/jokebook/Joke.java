package com.example.jokebook;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Joke {
    public String uid;
    public String key;
    public String content;
    public int like;
    public String date;
    //public String title;
    public Joke(){}
    public Joke(String content , String uid , String key )
    {
       // this.title = title;
        this.key = key;
        this.uid = uid;
        this.content = content;
        this.like = 0;
        this.date = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date());
    }

    public String getContent() {
        return content;
    }

    public void setKey(String key) {
        this.key = key;
    }

    @Override
    public String toString() {
        return content + "\n" + date + "\n" + String.valueOf(like);
    }
}