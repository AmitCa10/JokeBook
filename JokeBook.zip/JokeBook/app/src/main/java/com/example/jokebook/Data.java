package com.example.jokebook;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class Data {
    public static Joke bestJokeForToday;
    public static Joke bestJokeForEver;
    public static ArrayList<Joke> myJoke;
    public static ArrayList<Joke> buzzJokes;
    public static UserDetails ud;
    public static int pos;
    private static Context context;
    public static void rest(){
        Data.myJoke.clear();
    }
    public static void load(Context context){
        Data.context = context;
        loadMyJoke();
        //goIntent();
    }
    public static void loadTheBest1(){
        Query query = FirebaseFirestore.getInstance().collection("Joke")
                .orderBy("like",Query.Direction.DESCENDING);

        query.limit(1).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if(task.isSuccessful()){
                    for (QueryDocumentSnapshot document : task.getResult()) {
                        if (document.exists()){
                            Data.bestJokeForEver = document.toObject(Joke.class);
                        }
                    }
                    Data.loadTheBest2();
                }
            }
        });
    }
    public static void loadTheBest2() {
        Query query = FirebaseFirestore.getInstance().collection("Joke")
                .orderBy("like", Query.Direction.DESCENDING);
        query.whereEqualTo("date", new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date()));
        query.limit(1).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    for (QueryDocumentSnapshot document : task.getResult()) {
                        if (document.exists()) {
                            Data.bestJokeForEver = document.toObject(Joke.class);
                        }
                    }
                    Data.goIntent();
                }
            }
        });
    }
    public static void loadBuzzed(){
        buzzJokes = new ArrayList<>();
        Query query = FirebaseFirestore.getInstance().collection("Jokes")
                .orderBy("like",Query.Direction.DESCENDING);

        query.whereEqualTo("date",new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date()));

        query.limit(10000).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                for (QueryDocumentSnapshot document : task.getResult()) {
                    if (document.exists()){
                        Joke kkk = document.toObject(Joke.class);
                        Data.buzzJokes.add(kkk);
                        Data.pos = kkk.like;
                    }
                }
                loadTheBest1();
            }
        });
    }
    public static void loadMyJoke(){
        myJoke = new ArrayList<>();
        FirebaseFirestore.getInstance().collection("Jokes")
                .whereEqualTo("uid", FirebaseAuth.getInstance().getCurrentUser().getUid())
                .get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if(task.isSuccessful()) {
                    for (QueryDocumentSnapshot document : task.getResult()) {
                        if (document.exists()){
                            Data.myJoke.add(document.toObject(Joke.class));
                        }
                    }
                }
                //goIntent();
                Data.loadBuzzed();

            }
        });
    }
    public static void loadMyDetails() {
        FirebaseFirestore.getInstance().collection("UserDetails")
                .whereEqualTo("userUid", FirebaseAuth.getInstance().getCurrentUser().getUid())
                .get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    for (QueryDocumentSnapshot document : task.getResult()) {
                        if(document.exists()) {
                            Data.ud = document.toObject(UserDetails.class);
                            Data.ud.setActiveDate();
                            FirebaseFirestore.getInstance().collection("UserDetails").document(Data.ud.key).set(Data.ud);
                        }
                    }
                }
                loadMyJoke();
            }
        });
    }
    public static void goIntent() {
        if (context != null) {
            context.startActivity(new Intent(context, MainActivity.class));
        }
    }
}
