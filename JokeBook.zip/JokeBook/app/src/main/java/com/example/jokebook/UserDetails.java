package com.example.jokebook;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class UserDetails {
    public String email;
    public String name;
    public int rank;
    public String seenJk;
    public String lastActiveDate;
    public String key;

    public UserDetails(){}
    public UserDetails(String email, String name, int rank,String seenJk, String key){
        this.email = email;
        this.name = name;
        this.rank = rank;
        this.seenJk = seenJk;
        this.lastActiveDate = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date());
        this.key = key;

    }
    public void setActiveDate(){
       this.lastActiveDate = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date());
    }
}
