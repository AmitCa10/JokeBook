package com.example.jokebook;


import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MeActivity extends AppCompatActivity {
    ListView lv;
    ArrayAdapter<Joke> myJokeAdapter;
    // JokesAdapter jokesAdapter;
    // DatabaseReference jokeRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_me);
        lv = findViewById(R.id.lv);
        myJokeAdapter = new ArrayAdapter<Joke>(this, android.R.layout.simple_list_item_1, Data.myJoke);
        lv.setAdapter(myJokeAdapter);
    }

    @Override
    protected void onResume() {
        myJokeAdapter.notifyDataSetChanged();
        super.onResume();
    }
    //    public  void retrieveData()
//    {
//        Toast.makeText(MeActivity.this , "suc" , Toast.LENGTH_LONG).show();
//        jokeRef.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(DataSnapshot dataSnapshot) {
//                ArrayList<Joke> jokes = new ArrayList<Joke>();
//                for(DataSnapshot data : dataSnapshot.getChildren())
//                {
//                    Joke j = data.getValue(Joke.class);
//                    jokes.add(j);
//                }
//                jokesAdapter = new JokesAdapter(MeActivity.this, 0 , 0 ,jokes);
//                lv.setAdapter(jokesAdapter);
//            }
//
//            @Override
//            public void onCancelled( DatabaseError databaseError) {
//                Toast.makeText(MeActivity.this , "err" , Toast.LENGTH_LONG).show();
//            }
//        });
//    }
}
