package com.example.jokebook;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;


public class LoginActivity extends AppCompatActivity implements View.OnClickListener, RadioGroup.OnCheckedChangeListener {

    Button signupBtn, loginBtn, suBtn;
    Dialog signupd;
    EditText suEmail, suPw, suFjk, lgEmail, lgPw , suFName;
    RadioGroup genderq;
    RadioButton male , female;
    private FirebaseAuth mAuth;
    //final String TAG = "tag";
    int mode = 0; // 0 sign up 1 login
    boolean gender;

    //Intent intent =


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        loginBtn = (Button) findViewById(R.id.loginbtn);
        signupBtn = (Button) findViewById(R.id.signupBtn);
        loginBtn.setOnClickListener(this);
        signupBtn.setOnClickListener(this);
        //  mAuth = FirebaseAuth.getInstance();
        lgEmail = (EditText)findViewById(R.id.lgEmail);
        lgPw = (EditText)findViewById(R.id.lgPw);

        if(FirebaseAuth.getInstance().getCurrentUser() != null){
            Data.load(LoginActivity.this);
        }


        //       firebaseDatabase = FirebaseDatabase.getInstance();

        // FirebaseUser firebaseUser = mAuth.getCurrentUser();
//        if (firebaseUser != null) {
//            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
//            startActivity(intent);
//        }

    }

    public void signUpDialog() {
        signupd = new Dialog(this);
        signupd.setContentView(R.layout.signup_dialog);
        signupd.setTitle("Sign Up");
        signupd.setCancelable(true);
        suEmail = (EditText) signupd.findViewById(R.id.suEmail);
        suPw = (EditText) signupd.findViewById(R.id.suPassword);
        suBtn = (Button) signupd.findViewById(R.id.subtn);
        genderq = (RadioGroup) signupd.findViewById(R.id.gender);
        suFjk = (EditText)findViewById(R.id.suFjk);
        suFName = (EditText)signupd.findViewById(R.id.suFName);
        genderq.setOnCheckedChangeListener(this);
        signupd.show();
        suBtn.setOnClickListener(this);


    }

//    @Override
//    public void onStart() {
//        super.onStart();
//        // Check if user is signed in (non-null) and update UI accordingly.
//        FirebaseUser currentUser = mAuth.getCurrentUser();
//        // updateUI(currentUser);
//    }

    public void login()
    {
        FirebaseAuth fa = FirebaseAuth.getInstance();
        fa.signInWithEmailAndPassword(lgEmail.getText().toString(),lgPw.getText().toString()).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()) {
                    Data.load(LoginActivity.this);
                }
                else Toast.makeText(LoginActivity.this, "Email or Password is wrong", Toast.LENGTH_LONG).show();
            }
        });
    }

    public void register(){
        FirebaseAuth.getInstance().createUserWithEmailAndPassword(suEmail.getText().toString(),suPw.getText().toString()).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()) {

                    final UserDetails ud1 = new UserDetails(suEmail.getText().toString(), suFName.getText().toString(),0,null,"");
                    FirebaseFirestore.getInstance().collection("UserDetails").add(ud1).addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                        @Override
                        public void onSuccess(DocumentReference documentReference) {
                            ud1.key = documentReference.getId();
                            documentReference.set(ud1);
                        }
                    });
                    Data.load(LoginActivity.this);
                }

            }
        });
    }

//    public void signUp() {
//
//        mAuth.createUserWithEmailAndPassword(suEmail.getText().toString(), suPw.getText().toString())
//                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
//                    @Override
//                    public void onComplete(@NonNull Task<AuthResult> task) {
//                        if (task.isSuccessful()) {
//                            // Sign in success, update UI with the signed-in user's information
//                            Log.d(TAG, "createUserWithEmail:success");
//                            Toast.makeText(LoginActivity.this, "Authentication succeed",
//                                    Toast.LENGTH_SHORT).show();
//                            FirebaseUser user = mAuth.getCurrentUser();
//                            signupd.dismiss();
//                            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
//                            startActivity(intent);
//                            // updateUI(user);
//                        } else {
//                            // If sign in fails, display a message to the user.
//                            Log.w(TAG, "createUserWithEmail:failure", task.getException());
//                            Toast.makeText(LoginActivity.this, "Authentication failed.",
//                                    Toast.LENGTH_SHORT).show();
//                            // updateUI(null);
//                        }
//
//
//
//                        // ...
//                    }
//                });
    //  }

    @Override
    public void onClick(View v) {
        if (v == loginBtn) {
            login();
        } else if (v == signupBtn) {
            signUpDialog();

        } else if (v == suBtn) {
//            String uid = FirebaseAuth.getInstance().getCurrentUser().getUid().toString();
//            Joke j = new Joke( uid , suFjk.getText().toString()  , " "  ); //etitle.getText().toString() );
//            jokeRef = firebaseDatabase.getReference("Jokes").push();
//            j.key = jokeRef.getKey();
//            jokeRef.setValue(j);
//            JBUser ubj = new JBUser(suEmail.getText().toString() , uid , suFName.getText().toString() );
//            userRef.setValue(ubj);
//            userRef = firebaseDatabase.getReference("Users").push();
            //  signUp();
            register();
            signupd.dismiss();
        }


    }

    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {
        if (group == genderq)
        {
            gender = (checkedId == R.id.q1male);
        }

    }
}