package com.example.jokebook;

import android.app.Dialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.lorentzos.flingswipe.SwipeFlingAdapterView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {


    //private ArrayList<String> al;
    public static ArrayAdapter<Joke> arrayAdapter;
    private int i;
    private FirebaseAuth mAuth;
    Dialog newJk;
    Button addJk , nJkBtn , meBtn , bestjk;
    EditText etnewJk;
    String uid;
    int pos;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        mAuth = FirebaseAuth.getInstance();
        nJkBtn = (Button)findViewById(R.id.newjk_btn);
        nJkBtn.setOnClickListener(this);
        meBtn = (Button)findViewById(R.id.me_btn);
        uid = FirebaseAuth.getInstance().getCurrentUser().getUid();



        arrayAdapter = new ArrayAdapter<>(this, R.layout.card, R.id.helloText, Data.buzzJokes);
        pos = Data.pos;
        SwipeFlingAdapterView flingContainer = (SwipeFlingAdapterView) findViewById(R.id.frame);

        flingContainer.setAdapter(arrayAdapter);
        flingContainer.setFlingListener(new SwipeFlingAdapterView.onFlingListener() {
            @Override
            public void removeFirstObjectInAdapter() {
                // this is the simplest way to delete an object from the Adapter (/AdapterView)
                Log.d("LIST", "removed object!");
                Data.buzzJokes.remove(0);
                arrayAdapter.notifyDataSetChanged();
            }

            @Override
            public void onLeftCardExit(Object dataObject) {
                //Do something on the left!
                //You also have access to the original object.
                //If you want to use it just cast it (String) dataObject
                Toast.makeText(MainActivity.this , "left" , Toast.LENGTH_LONG).show();
            }

            @Override
            public void onRightCardExit(Object dataObject) {
                Toast.makeText(MainActivity.this , "right" , Toast.LENGTH_LONG).show();
            }

            @Override
            public void onAdapterAboutToEmpty(int itemsInAdapter) {
                // Ask for more data here
                //al.add("בשבילך נגמרו הבדיחות...");
                Toast.makeText(MainActivity.this , "000" , Toast.LENGTH_LONG).show();

                //MainActivity.this.loadMoreBuzzed(20);
                Log.d("LIST", "notified");
                i++;
            }

            @Override
            public void onScroll(float scrollProgressPercent) {
            }
        });


        // Optionally add an OnItemClickListener
        flingContainer.setOnItemClickListener(new SwipeFlingAdapterView.OnItemClickListener() {
            @Override
            public void onItemClicked(int itemPosition, Object dataObject) {
                Toast.makeText(MainActivity.this , "clicked" , Toast.LENGTH_LONG).show();

            }
        });
        meBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MeActivity.class);
                startActivity(intent);
            }
        });
    }

    public void seen(String id){

    }
//    public void loadMoreBuzzed(int po){
//
//        Query query = FirebaseFirestore.getInstance().collection("Jokes")
//                .orderBy("like",Query.Direction.DESCENDING);
//
//        query.whereEqualTo("date",new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date()));
//
//        query.whereLessThan("like",0); //!
//
//        query.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
//            @Override
//            public void onComplete(@NonNull Task<QuerySnapshot> task) {
//                for (QueryDocumentSnapshot document : task.getResult()) {
//                    if (document.exists()){
//                        Joke kkk = document.toObject(Joke.class);
//                        Data.buzzJokes.add(kkk);
//                        MainActivity.this.pos = kkk.like;
//                    }
//                }
//                MainActivity.this.arrayAdapter.notifyDataSetChanged();
//            }
//        });
//    }
    public void jokeWritingDialog() {
        newJk = new Dialog(this);
        newJk.setContentView(R.layout.joke_writing_dialog);
        newJk.setTitle("Sign Up");
        newJk.setCancelable(true);
        etnewJk = (EditText) newJk.findViewById(R.id.etNewjk);
        addJk = (Button) newJk.findViewById(R.id.btnNewjk);
        addJk.setOnClickListener(this);
        newJk.show();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.logout_menu , menu);
        return true;

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);
        int id = item.getItemId();
        if (id == R.id.action_logout)
        {
            mAuth.signOut();
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
            Toast.makeText(MainActivity.this , "it was fun was'nt it?!" , Toast.LENGTH_LONG).show();
        }
        return true;
    }
    public void addNewJoke (final Joke joke) {
        FirebaseFirestore.getInstance().collection("Jokes").add(joke).addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
            @Override
            public void onSuccess(DocumentReference documentReference) {
                joke.key = documentReference.getId();
                documentReference.set(joke);
                Data.myJoke.add(joke);
            }
        });
    }
    @Override
    public void onClick(View v) {
        if (v == nJkBtn)
        {
            jokeWritingDialog();
        }
        else if (v == addJk)
        {
            String uid = FirebaseAuth.getInstance().getCurrentUser().getUid().toString();
            Joke j = new Joke( etnewJk.getText().toString()  , uid , "" );
            addNewJoke(j);
            newJk.dismiss();
        }
    }
}
